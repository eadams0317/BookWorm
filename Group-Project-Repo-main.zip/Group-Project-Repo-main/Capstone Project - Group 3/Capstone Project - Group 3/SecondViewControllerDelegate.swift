//
//  SecondViewControllerDelegate.swift
//  Capstone Project - Group 3
//
//  Created by user934517 on 11/28/23.
//

import Foundation

protocol SecondViewControllerDelegate: AnyObject {
    func secondViewControllerDidClose()
}
